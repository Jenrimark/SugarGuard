# SugarGuard 单元测试文档

日期：2026-05-04

## 测试对象

本次按用户给定名称执行，但结合仓库真实代码做如下映射：

- `UserDao` -> [`UserDao.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/UserDao.kt)
- `MealDao` -> [`MealRecordDao.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt)
- `AuthService` -> 仓库实际对应 [`LocalAuthViewModel.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt)
- `ChatViewModel` -> 仓库实际对应 [`AIServiceViewModel.java`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java) 中的聊天与状态管理职责

## 新增测试文件

- [`UserDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/UserDaoTest.kt)
- [`MealRecordDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/MealRecordDaoTest.kt)
- [`LocalAuthViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/LocalAuthViewModelTest.kt)
- [`AIServiceViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/AIServiceViewModelTest.kt)
- 测试辅助：
  - [`FakeRetrofitCall.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/testutil/FakeRetrofitCall.kt)
  - [`LiveDataTestExtensions.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/testutil/LiveDataTestExtensions.kt)

## 技术方案

- 测试框架：JUnit Platform + JUnit 4 Runner 兼容执行
- Mock：MockK
- 协程测试：`kotlinx-coroutines-test`
- DAO 测试：Room In-Memory DB
- Android 本地单测运行环境：Robolectric
- ViewModel 状态断言：LiveData 同步观察扩展

相关依赖已配置在 [`app/build.gradle.kts`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/build.gradle.kts)。

## 覆盖范围

### 1. UserDao

覆盖文件：[`UserDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/UserDaoTest.kt)

已覆盖：
- Happy Path：用户名和密码匹配时返回用户
- Edge Case：查询不存在用户名返回 `null`
- State/Data：`Flow` 查询可读出更新后的用户信息

当前未覆盖但建议补充：
- 重复用户名约束
- 密码字段安全改造后的登录行为
- 删除用户后的级联影响

### 2. MealDao / MealRecordDao

覆盖文件：[`MealRecordDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/MealRecordDaoTest.kt)

已覆盖：
- Happy Path：按时间升序读取当日饮食记录
- Logic：糖分汇总结果正确
- Edge Case：最近日期列表去重并按倒序返回
- State/Data：按 `mealId` 删除后不可再查询到记录

当前未覆盖但建议补充：
- 负糖分/负热量非法数据拦截
- 空结果下汇总字段回零
- 大量记录下日期范围查询性能回归

### 3. AuthService / LocalAuthViewModel

覆盖文件：[`LocalAuthViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/LocalAuthViewModelTest.kt)

已覆盖：
- Happy Path：登录成功后写入用户态并返回 `loginResult`
- Edge Case：登录网络超时后返回错误消息
- Validation：注册时两次密码不一致直接失败
- Recovery：注册成功但自动登录失败时回退到本地用户缓存
- State Change：`isLoading`、`loginResult`、`registerResult`、`errorMessage` 状态变化

当前未覆盖但建议补充：
- 服务端 4xx/5xx 错误消息映射
- token 为空但用户信息存在时的登录态判断
- 并发重复点击登录/注册

### 4. ChatViewModel / AIServiceViewModel

覆盖文件：[`AIServiceViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/AIServiceViewModelTest.kt)

已覆盖：
- Happy Path：聊天成功后发布 `chatResponse`
- Edge Case：聊天网络超时后返回错误消息
- Validation：识别饮品时图片文件不存在，直接本地失败
- State Change：`isLoading`、`chatResponse`、`errorMessage` 状态变化

当前未覆盖但建议补充：
- 空消息、超长消息、空白消息
- API 成功但 `data == null` 的异常分支
- 多次连续请求下旧状态被新状态覆盖的行为

## 执行方式

在项目根目录执行：

```bash
./gradlew :app:testDebugUnitTest
```

最近一次校验结果：

```bash
BUILD SUCCESSFUL
```

## 备注

- 本次已实现“单元测试 + 文档留存”。
- 由于仓库实际不存在字面上的 `AuthService` 与 `ChatViewModel` 类，测试是按真实职责类落地，而不是伪造同名文件。
- 审查结论、架构风险和后续整改项可参考 [SugarGuard-模块质量保障文档-2026-05-04.md](/Users/Jenrimark/Documents/CODE/SugarGuard/docs/SugarGuard-模块质量保障文档-2026-05-04.md)。
