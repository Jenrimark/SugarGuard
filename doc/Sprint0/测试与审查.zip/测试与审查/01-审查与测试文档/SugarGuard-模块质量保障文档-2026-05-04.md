# SugarGuard 模块质量保障文档

审查日期：2026-05-04

审查对象：
- `UserDao` -> [`app/src/main/java/com/example/myapplication/db/dao/UserDao.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/UserDao.kt)
- `MealDao` -> [`app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt)
- `AuthService` -> 仓库中实际对应 [`LocalAuthViewModel.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt)
- `ChatViewModel` -> 仓库中实际对应 [`AIServiceViewModel.java`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java) 的聊天职责

## 审查结论

### 代码健壮性 (Robustness)

- `UserDao` 的登录查询直接以 `username + password` 明文匹配，虽然空指针风险低，但密码错误与数据泄露的爆炸半径非常高。见 [`UserDao.kt:9`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/UserDao.kt:9)。
- `MealRecordDao` 本身没有空指针问题，但所有核心查询都假设 `userId/date/mealId` 已经过业务层校验；DAO 层未提供任何约束兜底。见 [`MealRecordDao.kt:9`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:9) 到 [`MealRecordDao.kt:40`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:40)。
- `LocalAuthViewModel` 的异常捕获仅覆盖 Retrofit 回调失败，没有处理本地持久化失败、脏 token、重复点击并发登录等情况。`login()`/`register()` 在请求飞行中也没有幂等保护。见 [`LocalAuthViewModel.kt:33`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:33) 到 [`LocalAuthViewModel.kt:149`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:149)。
- `AIServiceViewModel.chat()` 缺少对 `message` 为空、超长、仅空白字符串的前置校验；`userId` 参数也未校验。见 [`AIServiceViewModel.java:253`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:253) 到 [`AIServiceViewModel.java:289`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:289)。
- `AIServiceViewModel` 和 `LocalAuthViewModel` 都直接持有静态 `RetrofitClient` 依赖，导致测试替身与异常注入困难，属于可测试性弱、恢复路径难验证的典型信号。见 [`LocalAuthViewModel.kt:18`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:18)、[`AIServiceViewModel.java:54`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:54)。

### 业务逻辑一致性 (Logic Check)

- “青少年控糖”场景下，最关键的问题是糖分、热量等营养值没有被强校验。`MealRecordEntity` 允许任意 `Double`，`MealRecordDao` 聚合时也照单全收，意味着负糖分、负热量会直接污染日报统计。见 [`MealRecordEntity.kt:28`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/entity/MealRecordEntity.kt:28) 到 [`MealRecordEntity.kt:33`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/entity/MealRecordEntity.kt:33)、[`MealRecordDao.kt:21`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:21) 到 [`MealRecordDao.kt:31`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:31)。
- 与之配套的写入侧同样缺少业务闭环。`LocalMealRepository.addMeal()` 在落库前不校验 `foodName`、`mealType`、`sugarContent`、`calories` 的边界。见 [`LocalMealRepository.kt:26`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/repository/LocalMealRepository.kt:26) 到 [`LocalMealRepository.kt:48`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/repository/LocalMealRepository.kt:48)。
- `LocalAuthViewModel.register()` 只校验“确认密码一致”，没有用户名长度、密码强度、邮箱合法性、生日是否为未成年用户可接受范围等校验，不符合青少年健康产品的合规预期。见 [`LocalAuthViewModel.kt:69`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:69) 到 [`LocalAuthViewModel.kt:88`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:88)。
- `LocalAuthViewModel.autoLoginAfterRegister()` 在自动登录失败时仍写入 `user_id/username`，但不写 token；这会制造“已注册但未真正认证”的半登录态。见 [`LocalAuthViewModel.kt:118`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:118) 到 [`LocalAuthViewModel.kt:148`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:148)。
- `AIServiceViewModel.chat()` 没有针对医疗/营养建议场景的输入边界和输出分级，容易把无效输入直接透传给后端大模型。见 [`AIServiceViewModel.java:257`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:257) 到 [`AIServiceViewModel.java:279`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:279)。

### 架构合规性 (Clean Architecture)

- 当前前端没有真正的 `AuthService` / `ChatViewModel` 分层，而是把认证和 AI 业务直接塞进 `AndroidViewModel`。这会让 UI 状态管理、网络访问、会话持久化混在一起，违反 Clean Architecture 的边界分离原则。见 [`LocalAuthViewModel.kt:15`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:15) 到 [`LocalAuthViewModel.kt:185`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:185)、[`AIServiceViewModel.java:38`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:38) 到 [`AIServiceViewModel.java:395`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:395)。
- ViewModel 虽未直接持有 `Activity/View` 引用，但 `AndroidViewModel + SharedPreferences + File + Retrofit static singleton` 已经明显越过纯状态层职责。
- DAO 层暂未越权到网络或 UI，但数据库实体缺少索引、唯一约束、校验约束，说明“边界清晰”不等于“边界可靠”。见 [`MealRecordEntity.kt:7`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/entity/MealRecordEntity.kt:7)、[`UserEntity.kt:6`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/entity/UserEntity.kt:6)。
- 数据库初始化回调中 `INSTANCE?.let` 在首次建库时可能拿不到实例，种子数据逻辑存在空转风险。见 [`AppDatabase.kt:49`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/AppDatabase.kt:49) 到 [`AppDatabase.kt:55`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/AppDatabase.kt:55)。

### 性能与安全 (Performance & Security)

- `UserDao` 与 `UserEntity` 当前是明文密码设计，这是最高优先级安全问题。见 [`UserDao.kt:9`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/UserDao.kt:9)、[`UserEntity.kt:10`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/entity/UserEntity.kt:10)。
- `LocalAuthViewModel.saveLoginState()` 将 `access_token`、`refresh_token` 明文存入 `SharedPreferences`，设备被 root、备份泄露或日志链路被抓取时风险极高。见 [`LocalAuthViewModel.kt:178`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:178) 到 [`LocalAuthViewModel.kt:184`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/LocalAuthViewModel.kt:184)。
- `RetrofitClient` 打开 `HttpLoggingInterceptor.Level.BODY`，会把登录请求体、Authorization Header 附带流量完整暴露到日志。测试、预发、生产都不应保留该级别。见 [`RetrofitClient.java:74`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/api/RetrofitClient.java:74) 到 [`RetrofitClient.java:77`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/api/RetrofitClient.java:77)。
- `meal_records` 表的高频查询条件集中在 `user_id + meal_date`、`user_id + meal_date BETWEEN`、`meal_id`，但实体没有索引声明；用户餐食数据累积后，日报与范围查询会持续退化。见 [`MealRecordDao.kt:9`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:9) 到 [`MealRecordDao.kt:31`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/db/dao/MealRecordDao.kt:31)。
- `AIServiceViewModel.bitmapToFile()` 手动操作流但未使用 `use {}`，异常中断时存在资源关闭不完整的风险。见 [`AIServiceViewModel.java:375`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:375) 到 [`AIServiceViewModel.java:384`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/main/java/com/example/myapplication/viewmodel/AIServiceViewModel.java:384)。

## 具体改进建议

### [严重]

- 移除明文密码链路：`UserDao.login()` 不应按明文密码查询；本地也不应存储明文密码字段。
- 将 `SharedPreferences` 中的 token 改为 `EncryptedSharedPreferences` 或 Keystore-backed 存储，并关闭 BODY 级网络日志。
- 为 `MealRecordEntity` / 写入服务增加非负校验、上限校验、空白值校验，防止负糖分和异常热量写入健康统计。
- 把 `LocalAuthViewModel`、`AIServiceViewModel` 中的网络调用和持久化逻辑下沉到 Repository / UseCase，消除 ViewModel 过重问题。

### [警告]

- 注册流程补充用户名长度、密码强度、邮箱格式、生日合法性与未成年人规则校验。
- `chat()` 增加空消息、超长消息、敏感医疗建议分流校验，并为失败场景定义一致的 UI 状态机。
- 为 `meal_records(user_id, meal_date)`、`meal_records(user_id, meal_date, meal_time)`、`users(username)` 增加索引/唯一约束。
- 修复 `AppDatabase` 首次建库时 seed callback 依赖 `INSTANCE` 的时序问题。

### [优化]

- `AIServiceViewModel` 的文件 IO 改用 `use {}`，统一清理策略并减少重复删除代码。
- 为登录、注册、聊天、饮食写入增加请求幂等控制，避免连续点击造成重复提交。
- 将错误消息从自由文本收敛为密封类或枚举型 UI state，降低多语言和状态同步成本。
- 为 DAO 增加更多约束型测试，例如重复用户名、极值糖分、空结果聚合、删除后的统计回归。

## 测试覆盖率说明

已新增测试：
- [`UserDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/UserDaoTest.kt)
- [`MealRecordDaoTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/db/dao/MealRecordDaoTest.kt)
- [`LocalAuthViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/LocalAuthViewModelTest.kt)
- [`AIServiceViewModelTest.kt`](/Users/Jenrimark/Documents/CODE/SugarGuard/app/src/test/java/com/example/myapplication/viewmodel/AIServiceViewModelTest.kt)

覆盖点：
- Happy Path：用户登录成功、DAO 读写成功、聊天成功。
- Edge Cases：找不到用户、网络超时、缺失图片文件、自动登录失败回退。
- State Change：`isLoading`、`loginResult`、`registerResult`、`chatResponse`、`errorMessage` 状态流转。
- 数据一致性：日报排序、糖分聚合、最近日期去重、删除后查询为空。

执行结果：

```bash
./gradlew :app:testDebugUnitTest
BUILD SUCCESSFUL
```

说明：
- 已启用 JUnit Platform。
- Android 相关单测采用 Robolectric + MockK + Coroutines Test Suite 运行，以保证 `Room`、`Application`、`LiveData` 场景可在本地 CI 中稳定执行。

## 后续 Action

- [ ] 修复 `AuthService`/`LocalAuthViewModel` 登录重试与 token 存储逻辑
- [ ] 优化 `MealDao`/`MealRecordDao` 聚合查询性能与索引
- [ ] 为青少年控糖场景补齐营养数据边界校验
- [ ] 把认证、聊天、饮食写入逻辑从 ViewModel 下沉到 Repository / UseCase
