package com.example.myapplication.viewmodel

import android.app.Application
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import com.example.myapplication.api.AIApiService
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.model.ApiResponse
import com.example.myapplication.model.ChatRequest
import com.example.myapplication.model.ChatResponse
import com.example.myapplication.testutil.FakeRetrofitCall
import com.example.myapplication.testutil.getOrAwaitValue
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import retrofit2.Response
import java.io.File
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class)
class AIServiceViewModelTest {
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var application: Application
    private lateinit var aiApiService: AIApiService

    @Before
    fun setUp() {
        application = ApplicationProvider.getApplicationContext()
        aiApiService = mockk()
        mockkStatic(RetrofitClient::class)
        every { RetrofitClient.getAIApiService() } returns aiApiService
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    @Test
    fun chatPublishesResponseAndClearsErrorOnSuccess() = runTest {
        // Given
        val payload = ChatResponse().apply {
            setSuccess(true)
            setResponse("建议今天把含糖饮料控制在一杯以内")
            setIntent("health_advice")
        }
        every { aiApiService.chat(any<ChatRequest>()) } returns FakeRetrofitCall.success(
            Response.success(apiResponse(success = true, data = payload))
        )
        val viewModel = AIServiceViewModel(application)

        // When
        viewModel.chat(7, "今天喝奶茶可以吗")

        // Then
        assertEquals(payload, viewModel.chatResponse.getOrAwaitValue())
        assertNull(viewModel.errorMessage.value)
        assertFalse(viewModel.isLoading.getOrAwaitValue())
    }

    @Test
    fun chatPublishesReadableErrorWhenNetworkFails() = runTest {
        // Given
        every { aiApiService.chat(any<ChatRequest>()) } returns FakeRetrofitCall.failure(IOException("timeout"))
        val viewModel = AIServiceViewModel(application)

        // When
        viewModel.chat(7, "今天喝奶茶可以吗")

        // Then
        assertEquals("网络错误: timeout", viewModel.errorMessage.getOrAwaitValue())
        assertFalse(viewModel.isLoading.getOrAwaitValue())
    }

    @Test
    fun recognizeDrinkRejectsMissingImageBeforeNetworkRequest() = runTest {
        // Given
        val viewModel = AIServiceViewModel(application)
        val missing = File(application.cacheDir, "missing-file.jpg")

        // When
        viewModel.recognizeDrink(7, missing)

        // Then
        assertEquals("图片文件不存在", viewModel.errorMessage.getOrAwaitValue())
        assertFalse(viewModel.isLoading.getOrAwaitValue())
    }

    private fun <T> apiResponse(success: Boolean, data: T? = null, message: String? = null): ApiResponse<T> {
        return ApiResponse<T>().apply {
            setSuccess(success)
            setData(data)
            setMessage(message)
        }
    }
}
