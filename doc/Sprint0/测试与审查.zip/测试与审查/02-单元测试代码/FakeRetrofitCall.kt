package com.example.myapplication.testutil

import okhttp3.Request
import okio.Timeout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FakeRetrofitCall<T> private constructor(
    private val response: Response<T>? = null,
    private val error: Throwable? = null
) : Call<T> {

    private var executed = false
    private var canceled = false

    override fun enqueue(callback: Callback<T>) {
        executed = true
        if (canceled) return
        error?.let {
            callback.onFailure(this, it)
            return
        }
        callback.onResponse(this, checkNotNull(response))
    }

    override fun execute(): Response<T> {
        executed = true
        error?.let { throw it }
        return checkNotNull(response)
    }

    override fun clone(): Call<T> = FakeRetrofitCall(response, error)

    override fun isExecuted(): Boolean = executed

    override fun cancel() {
        canceled = true
    }

    override fun isCanceled(): Boolean = canceled

    override fun request(): Request = Request.Builder().url("http://localhost/").build()

    override fun timeout(): Timeout = Timeout.NONE

    companion object {
        fun <T> success(response: Response<T>): FakeRetrofitCall<T> = FakeRetrofitCall(response = response)

        fun <T> failure(error: Throwable): FakeRetrofitCall<T> = FakeRetrofitCall(error = error)
    }
}
