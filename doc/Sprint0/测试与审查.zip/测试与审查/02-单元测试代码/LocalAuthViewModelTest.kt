package com.example.myapplication.viewmodel

import android.app.Application
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import com.example.myapplication.api.AuthApiService
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.model.ApiResponse
import com.example.myapplication.model.LoginRequest
import com.example.myapplication.model.LoginResponse
import com.example.myapplication.model.RegisterRequest
import com.example.myapplication.model.UserDto
import com.example.myapplication.testutil.FakeRetrofitCall
import com.example.myapplication.testutil.getOrAwaitValue
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import retrofit2.Response
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class)
class LocalAuthViewModelTest {
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var application: Application
    private lateinit var authApiService: AuthApiService

    @Before
    fun setUp() {
        application = ApplicationProvider.getApplicationContext()
        application.getSharedPreferences("auth_prefs", 0).edit().clear().commit()

        authApiService = mockk()
        mockkStatic(RetrofitClient::class)
        every { RetrofitClient.getAuthApiService() } returns authApiService
    }

    @After
    fun tearDown() {
        unmockkAll()
        application.getSharedPreferences("auth_prefs", 0).edit().clear().commit()
    }

    @Test
    fun loginStoresTokenAndPublishesUserOnSuccess() = runTest {
        // Given
        val user = UserDto(7, "guardian", "g@sugar.cn", null, null, null, null, "active")
        every { authApiService.login(any<LoginRequest>()) } returns FakeRetrofitCall.success(
            Response.success(apiResponse(success = true, data = LoginResponse("token-1", "refresh-1", 3600, user, "session-1")))
        )
        val viewModel = LocalAuthViewModel(application)

        // When
        viewModel.login("guardian", "123456")

        // Then
        assertEquals(user, viewModel.loginResult.getOrAwaitValue())
        assertTrue(viewModel.isLoggedIn())
        assertEquals("guardian", viewModel.getCurrentUsername())
        assertFalse(viewModel.isLoading.getOrAwaitValue())
    }

    @Test
    fun loginPublishesNetworkErrorOnFailure() = runTest {
        // Given
        every { authApiService.login(any<LoginRequest>()) } returns FakeRetrofitCall.failure(IOException("timeout"))
        val viewModel = LocalAuthViewModel(application)

        // When
        viewModel.login("guardian", "123456")

        // Then
        assertEquals("网络连接失败: timeout", viewModel.errorMessage.getOrAwaitValue())
        assertFalse(viewModel.isLoggedIn())
        assertFalse(viewModel.isLoading.getOrAwaitValue())
    }

    @Test
    fun registerStopsImmediatelyWhenPasswordsDoNotMatch() = runTest {
        // Given
        val viewModel = LocalAuthViewModel(application)

        // When
        viewModel.register("teen", "", "abc", "xyz", null, null, null)

        // Then
        assertEquals("两次输入的密码不一致", viewModel.errorMessage.getOrAwaitValue())
        assertFalse(viewModel.isLoading.getOrAwaitValue())
        assertNull(viewModel.registerResult.value)
    }

    @Test
    fun registerFallsBackToLocalUserCacheWhenAutoLoginFails() = runTest {
        // Given
        val user = UserDto(9, "teen", "teen@sugar.cn", null, null, null, null, "active")
        every { authApiService.register(any<RegisterRequest>()) } returns FakeRetrofitCall.success(
            Response.success(apiResponse(success = true, data = user))
        )
        every { authApiService.login(any<LoginRequest>()) } returns FakeRetrofitCall.failure(IOException("network down"))
        val viewModel = LocalAuthViewModel(application)

        // When
        viewModel.register("teen", "", "123456", "123456", null, null, null)

        // Then
        assertEquals(user, viewModel.registerResult.getOrAwaitValue())
        assertEquals("teen", viewModel.getCurrentUsername())
        assertFalse(viewModel.isLoggedIn())
    }

    private fun <T> apiResponse(success: Boolean, data: T? = null, message: String? = null): ApiResponse<T> {
        return ApiResponse<T>().apply {
            setSuccess(success)
            setData(data)
            setMessage(message)
        }
    }
}
