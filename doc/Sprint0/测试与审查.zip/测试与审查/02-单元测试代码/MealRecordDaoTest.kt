package com.example.myapplication.db.dao

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.myapplication.db.AppDatabase
import com.example.myapplication.db.entity.MealRecordEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class)
class MealRecordDaoTest {

    private lateinit var database: AppDatabase
    private lateinit var mealDao: MealRecordDao

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        mealDao = database.mealRecordDao()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun getDailyMealsReturnsAscendingTimeAndSugarAggregation() = runTest {
        // Given
        mealDao.insert(meal("08:00:00", "2026-05-04", 8.5))
        mealDao.insert(meal("12:30:00", "2026-05-04", 11.0))
        mealDao.insert(meal("07:30:00", "2026-05-04", 3.0))

        // When
        val meals = mealDao.getDailyMeals(1, "2026-05-04").first()
        val totalSugar = mealDao.getDailySugarTotal(1, "2026-05-04")

        // Then
        assertEquals(listOf("07:30:00", "08:00:00", "12:30:00"), meals.map { it.mealTime })
        assertEquals(22.5, totalSugar, 0.0001)
    }

    @Test
    fun getRecentDatesReturnsDistinctDatesInDescendingOrder() = runTest {
        // Given
        mealDao.insert(meal("08:00:00", "2026-05-04", 8.5))
        mealDao.insert(meal("09:00:00", "2026-05-04", 5.0))
        mealDao.insert(meal("08:00:00", "2026-05-03", 6.0))
        mealDao.insert(meal("08:00:00", "2026-05-01", 4.0))

        // When
        val dates = mealDao.getRecentDates(1, limit = 2)

        // Then
        assertEquals(listOf("2026-05-04", "2026-05-03"), dates)
    }

    @Test
    fun deleteByIdRemovesMealRecord() = runTest {
        // Given
        val mealId = mealDao.insert(meal("18:00:00", "2026-05-04", 12.0)).toInt()

        // When
        mealDao.deleteById(mealId)
        val deleted = mealDao.getMealById(mealId)

        // Then
        assertNull(deleted)
    }

    private fun meal(time: String, date: String, sugar: Double) = MealRecordEntity(
        userId = 1,
        mealDate = date,
        mealTime = time,
        mealType = "breakfast",
        foodName = "燕麦奶",
        sugarContent = sugar,
        calories = sugar * 10
    )
}
