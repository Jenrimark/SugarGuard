package com.example.myapplication.db.dao

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.myapplication.db.AppDatabase
import com.example.myapplication.db.entity.UserEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class)
class UserDaoTest {

    private lateinit var database: AppDatabase
    private lateinit var userDao: UserDao

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        userDao = database.userDao()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun loginReturnsUserWhenCredentialsMatch() = runTest {
        // Given
        val userId = userDao.insert(
            UserEntity(username = "teen_user", password = "safe-pass", email = "teen@sugar.cn")
        )

        // When
        val user = userDao.login("teen_user", "safe-pass")

        // Then
        assertNotNull(user)
        assertEquals(userId, user?.id)
        assertEquals("teen_user", user?.username)
    }

    @Test
    fun findByUsernameReturnsNullWhenUserMissing() = runTest {
        // Given
        userDao.insert(UserEntity(username = "known", password = "123456"))

        // When
        val user = userDao.findByUsername("missing")

        // Then
        assertNull(user)
    }

    @Test
    fun getUserByIdFlowEmitsUpdatedUser() = runTest {
        // Given
        val userId = userDao.insert(UserEntity(username = "before", password = "123456"))
        userDao.update(
            UserEntity(id = userId, username = "after", password = "123456", email = "after@sugar.cn")
        )

        // When
        val latest = userDao.getUserByIdFlow(userId).first()

        // Then
        assertEquals("after", latest?.username)
        assertEquals("after@sugar.cn", latest?.email)
    }
}
