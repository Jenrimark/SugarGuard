# 测试与审查交付清单

本目录用于课程项目提交，包含本次测试与代码审查涉及的主要材料。

## 目录结构

- `01-审查与测试文档`
  - 模块质量保障文档
  - 单元测试说明文档
  - 单元测试计划、用例与报告文档
- `02-单元测试代码`
  - 四个核心模块对应的测试代码
  - 测试辅助工具代码
- `03-被审查源码`
  - 本次审查与测试涉及的主要源代码
- `04-测试报告`
  - `./gradlew :app:testDebugUnitTest` 生成的 HTML 测试报告
- `05-配置文件`
  - 单元测试依赖与版本配置

## 本次重点对象

- `UserDao`
- `MealRecordDao`（对应需求中的 `MealDao`）
- `LocalAuthViewModel`（对应需求中的 `AuthService`）
- `AIServiceViewModel`（对应需求中的 `ChatViewModel`）

## 测试执行结果

- 执行命令：`./gradlew :app:testDebugUnitTest`
- 执行结果：`BUILD SUCCESSFUL`

## 打包建议

直接压缩当前 `测试与审查` 文件夹即可提交。
